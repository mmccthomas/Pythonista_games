.. include:: ../README.rst

Contents
--------

.. toctree::
    :maxdepth: 2

    core
    pgn
    polyglot
    gaviota
    syzygy
    engine
    svg
    variant

.. toctree::
    :maxdepth: 1

    changelog

Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`
